// rundir

// Copyright 2021 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Testing that all methods of a private generic type are exported, if a variable
// with that type is exported.

package ignored
