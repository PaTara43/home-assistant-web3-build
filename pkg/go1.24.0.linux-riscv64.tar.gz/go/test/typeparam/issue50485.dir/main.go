package main

import (
	"./a"
)

func main() {
	_ = a.OrdOption(a.Given[int]())
}
