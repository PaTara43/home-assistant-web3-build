package b

import "./a"

func Test() {
	var _ a.Slice[uint]
}
